package sample;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.*;
import javafx.scene.*;
import javafx.scene.text.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class Main extends Application {
    private PersonDataAccessor dataAccessor1;
    private SubjectDataAccessor dataAccessor2;


    @Override
    public void start(Stage primaryStage) throws Exception {
        dataAccessor1 = new PersonDataAccessor("com.mysql.cj.jdbc.Driver", "jdbc:mysql://localhost:3306/schedule","root", "root"); // provide driverName, dbURL, user, password...
        dataAccessor2 = new SubjectDataAccessor("com.mysql.cj.jdbc.Driver", "jdbc:mysql://localhost:3306/schedule","root", "root"); // provide driverName, dbURL, user, password...


        /*------1-------*/
        TableView<Person> personTable1 = new TableView<>();
        personTable1.setPrefSize(400, 400);

        TableColumn<Person, Integer> nullNameCol = new TableColumn<>("Id");
        nullNameCol.setCellValueFactory(new PropertyValueFactory<>("id"));

        TableColumn<Person, String> firstNameCol = new TableColumn<>("First Name");
        firstNameCol.setCellValueFactory(new PropertyValueFactory<>("lastName"));

        TableColumn<Person, String> lastNameCol = new TableColumn<>("Last Name");
        lastNameCol.setCellValueFactory(new PropertyValueFactory<>("firstName"));

        TableColumn<Person, String> patrCol = new TableColumn<>("Patronymic");
        patrCol.setCellValueFactory(new PropertyValueFactory<>("patronymic"));

        personTable1.getColumns().addAll(nullNameCol, firstNameCol, lastNameCol, patrCol);

        personTable1.getItems().addAll(dataAccessor1.getPersonList());
        /*------1-finish-------*/

        /*------2-start-------*/
        TableView<Subject> personTable2 = new TableView<>();
        personTable2.setPrefSize(400, 400);

        TableColumn<Subject, Integer> id = new TableColumn<>("Id");
        id.setCellValueFactory(new PropertyValueFactory<>("id"));

        TableColumn<Subject, String> firstNameCol2 = new TableColumn<>("Subject");
        firstNameCol2.setCellValueFactory(new PropertyValueFactory<>("name"));

        personTable2.getColumns().addAll(id, firstNameCol2);

        personTable2.getItems().addAll(dataAccessor2.getSubjectList());
        /*------2-finish-------*/

        FlowPane root = new FlowPane();

       // root.getChildren().add(personTable1);
        root.setStyle("-fx-background-color: #FFEBCD");
        root.setAlignment(Pos.CENTER);

        Stage firstTable = new Stage();
        Scene first = new Scene(personTable1, 400, 450);
        firstTable.setScene(first);

       Stage secondTable = new Stage();
        Scene second = new Scene(personTable2, 400, 450);
        secondTable.setScene(second);

        /**/
        Text textForUser1 = new Text("Для просмотра всех\n преподавателей,\n нажмите кнопку:");
        textForUser1.setFont(new Font("Oracle R", 16));

        Button button1 = new Button("Set table1");
        button1.setPrefSize(200, 40);

        Text textForUser2 = new Text("Для просмотра всех\n предметов,\n нажмите кнопку:");
        textForUser2.setFont(new Font("Oracle R", 16));

        Button button2 = new Button("Set table2");
        button2.setPrefSize(200, 40);

        root.setHgap(100);
        root.setVgap(50);

        root.getChildren().addAll(textForUser1, button1, textForUser2, button2);

        /**/

        button1.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                firstTable.show();
            }
        });

        button2.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                secondTable.show();
            }
        });

        Scene scene = new Scene(root, 600, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    @Override
    public void stop() throws Exception {
        if (dataAccessor1 != null) {
            dataAccessor1.shutdown();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
